(function () {
    'use strict';

    angular
        .module('app.about-us')
        .controller('AboutUsController', AboutUsController);

    AboutUsController.$inject = ['EventBus'];

    function AboutUsController(EventBus){
        var ctrl = this;

    };
})();
