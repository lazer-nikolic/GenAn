(function () {
    'use strict';

    angular
        .module('app.about-us', [
            'app.eventbus'
        ]);
})();
