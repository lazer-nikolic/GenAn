(function () {
    'use strict';

    angular
        .module('app')
        .controller('IndexController', IndexController);

    IndexController.$inject = ['$scope', '$location', '$anchorScroll'];

    function IndexController($scope, $location, $anchorScroll){
    	$scope.scrollTo = function(id) {
	      $location.hash(id);
	      $anchorScroll();
	   	}
    };
})();
