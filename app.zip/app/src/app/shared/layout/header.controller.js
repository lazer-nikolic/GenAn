(function () {
    'use strict';

    angular
        .module('app.layout')
        .directive('header', function () {
            return {
                restrict: 'E',
                templateUrl: 'app/shared/layout/header.html',
                controller: 'HeaderController',
                controllerAs: 'ctrl'
            }
        })
        .controller('HeaderController', HeaderController);

    HeaderController.$inject = ['$translate'];

    function HeaderController($translate) {
        var ctrl = this;

        ctrl.serbian = true;

        ctrl.toggleLanguage = function (condition) {
            ctrl.serbian = condition;
            $translate.use(condition ? 'en_us' : 'sr_lat');
        };
    }
})();
