(function () {
    'use strict';

    angular
        .module('app.config', [])
        .constant('clientConfigurationValues', {});
})();