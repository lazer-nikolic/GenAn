(function () {
    'use strict';

    angular
        .module('app.translation')
        .factory('DynamicTranslation', DynamicTranslation);

    DynamicTranslation.$inject = ['$http', 'ngResource'];

    function DynamicTranslation($http, $resource) {
        var url = 'http://localhost:8080/translation/:languageId';

         return {
            getTranslations: getTranslations
        };

        getTranslations = function() {
           return $resource(url ,null, {
            'query': {method:'GET', isArray:true}
            });
        }
    };
});