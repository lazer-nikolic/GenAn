(function () {
    'use strict';

    var app = angular
        .module('app.translation');

    app.config(function ($translateProvider) {
        $translateProvider.useLoader('customLoader', {});

        $translateProvider.preferredLanguage('en_us');

        $translateProvider.useSanitizeValueStrategy('sanitize');
    });


    app.factory('customLoader', function ($q, $timeout, $http) {
        
        return function (options) {
            var deferred = $q.defer(), translations;

            if (options.key == 'en_us') {
                translations = {
                    ERROR_TITLE: 'Error',
                    ERROR_MESSAGE: 'There was an error executing operation.',
                    OK: 'OK',
                    CANCEL: 'Cancel',
                    YES: 'Yes',
                    NO: 'No',
                    NEXT: 'Next',
                    BACK: 'Back',
                    USERS: 'Users',
                    ABOUT_US: 'About us',
                    START_END_DATE_FORMAT: 'Start-end date interval is invalid.',
                    ONLY_LETTERS_ALLOWED: 'Only letters are allowed for this field.',
                    ONLY_DIGITS_ALLOWED: 'Only digits are allowed for this field.',
                    REQUIRED: 'This field is required.',
                    STARTDATE: 'Start date',
                    REVIEW: 'Review',
                    TABLE: 'Table',
                    TABLE_VIEW: 'Table view',
                    FIRST_NAME: "First name",
                    LAST_NAME: "Last name",
                    SUBMIT: 'Submit',
                    UPDATE: 'Update',
                    CREATE: 'Create',
                    SAVE: 'Save',
                    DELETE: 'Delete',
                    RESTART_UPDATE: 'Reset to initial value',
                    DELETE_SELECTED_QUESTION: "Would you like to delete selected item?",
                    CONTINUE: 'Continue',
                    TODAY: 'Today',
                    CLEAR: 'Clear',
                    CLOSE: 'Close',
                    DATEFORMAT: 'MM/dd/yyyy',
                    NONE: 'Select option',
                    NONE_OPTIONAL: 'None',
                    SUCCESS_TRANSACTION: 'Successful transaction!',
                    BACK_TO_INDEX: 'Back to home page',
                    FAIL_TRANSACTION: 'Failed transaction',
                    RETRY: 'Retry',
                    WE_ARE: 'We are GenAn!',
                    LIFE_IS_CASINO: 'Life is casino',
                    YOU_ARE_BAD: 'Bad',
                    AND_OTHERS:'And many others...',
                    //index
                    INDEX_HEADING: 'DSL',
                    INDEX_CONTACT: 'Contact',
                    INDEX_CONTACT_NAME: 'Your name',
                    INDEX_CONTACT_EMAIL: 'Your email address',
                    INDEX_CONTACT_TEXT: 'Message text',
                    INDEX_CONTACT_SEND: 'Send',
                    INDEX_CONTACT_ADDRESS: 'Address',
                    INDEX_CONTACT_SOCIAL: 'Social',
                    START_JOURNEY: 'Start your journey!'
                };
            } else {
                translations = {
                    ERROR_TITLE: 'Greška',
                    ERROR_MESSAGE: 'Dogodila se greška prilikom izvršavanja operacije.',
                    OK: 'U redu',
                    CANCEL: 'Otkaži',
                    YES: 'Da',
                    NO: 'Ne',
                    NEXT: 'Sledeći',
                    BACK: 'Prethodni',
                    USERS: 'Korisnici',
                    ABOUT_US: 'O nama',
                    START_END_DATE_FORMAT: 'Datumski interval nije validan.',
                    ONLY_LETTERS_ALLOWED: 'Samo slova su dozvoljena za ovo polje.',
                    ONLY_DIGITS_ALLOWED : 'Samo cifre su dozvoljene za ovo polje',
                    REQUIRED: 'Obavezno polje.',
                    STARTDATE: 'Datum početka:',
                    REVIEW: 'Review',
                    TABLE: 'Table',
                    TABLE_VIEW: 'Table view',
                    ENDDATE: 'Datum kraja',
                    FIRST_NAME:"Ime",
                    LAST_NAME:"Prezime",
                    SUBMIT: 'Pošalji',
                    UPDATE: 'Izmeni',
                    CREATE: 'Kreiraj',
                    SAVE: 'Sačuvaj',
                    DELETE: 'Obriši',
                    RESTART_UPDATE: 'Resetuj na početnu vrednost',
                    DELETE_SELECTED_QUESTION: "Da li biste želeli da uklonite odabranu stavku?",
                    CONTINUE: 'Nastavi',
                    TODAY: 'Danas',
                    CLEAR: 'Obriši',
                    CLOSE: 'Zatvori',
                    DATEFORMAT: 'dd.MM.yyyy',
                    NONE: 'Selektujte opciju',
                    NONE_OPTIONAL: 'Nijedna opcija',
                    SUCCESS_TRANSACTION: 'Uspešna transakcija!',
                    BACK_TO_INDEX: 'Nazad na početnu stranu',
                    FAIL_TRANSACTION: 'Neuspešna transakcija',
                    RETRY: 'POkušaj ponovo',
                    WE_ARE: 'Svi smo mi GenAn!',
                    LIFE_IS_CASINO: 'Život je kazino',
                    YOU_ARE_BAD: 'Loša',
                    AND_OTHERS:'I mnoge druge...',
                    //index
                    INDEX_HEADING: 'DSL',
                    INDEX_CONTACT: 'Kontakt',
                    INDEX_CONTACT_NAME: 'Vaše ime',
                    INDEX_CONTACT_EMAIL: 'Vaša email adresa',
                    INDEX_CONTACT_TEXT: 'Tekst poruke',
                    INDEX_CONTACT_SEND: 'Pošalji',
                    INDEX_CONTACT_ADDRESS: 'Adresa',
                    INDEX_CONTACT_SOCIAL: 'Socijalne mreže',
                    START_JOURNEY: 'Započni putovanje!'
                };
            }


            deferred.resolve(translations);


            return deferred.promise;


        };
    });

    // var url = 'http://localhost:8080/xws/api/drzave/:languageId';

    //      return {
    //         getTranslations: getTranslations
    //     };

    //     getTranslations = function() {
    //        return $resource(url ,null, {
    //         'query': {method:'GET', isArray:true}
    //         });
    //     }
})();
