(function () {
    'use strict';

    angular
        .module('app.eventbus')
        .factory('Routing', RoutingService);

    RoutingService.$inject = ['$state', 'EventBus'];

    function RoutingService($state, EventBus) {

        EventBus.onEvent('GoToAboutUs', function (event, payload) {
            $state.go('about', payload);
        });

        EventBus.onEvent('GoToFormUser', function (event, payload) {
            $state.go('users.form', payload);
        });

        EventBus.onEvent('GoToTableUser', function (event, payload) {
            $state.go('users.table', payload);
        });

        return {};
    }
})();