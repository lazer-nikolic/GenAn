(function () {
    'use strict';

    angular
        .module('app.eventbus')
        .factory('EventBus', EventBus);

    EventBus.$inject = ['$rootScope'];

    function EventBus($rootScope) {

        var EventBus = {};
        EventBus.emitEvent = function (eventName, data) {
            data = data || {};
            $rootScope.$emit(eventName, data);
        };

        EventBus.onEvent = function (eventName, func, scope) {
            var unbind = $rootScope.$on(eventName, func);
            if (scope) {
                scope.$on('$destroy', unbind);
            }
            return unbind;
        };

        return EventBus;
    }
}());