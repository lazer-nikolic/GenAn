angular.module('app.config', [])
.constant('clientConfigurationValues', {});
