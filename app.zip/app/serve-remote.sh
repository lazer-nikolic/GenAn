#!/usr/bin/env bash
npm install
bower install
gulp config-development-remote serve
